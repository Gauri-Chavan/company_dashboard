import express from "express";
import jwt from "jsonwebtoken";
import User from "./model.js";

const router = express.Router();


// Login Route
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
console.log(req.body);

    // Check user
    const user = await User.findOne({ email });
    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials!",  success : false });
    }
  

    // Generate token (2 hour expiry)
    const token = jwt.sign(
      { id: user._id, roles: user.roles },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    return res.json({
      success : true,
      message: "Login successful",
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.name,
        roles: user.roles,
      },
    });
  } catch (err) {
    console.error("Login Error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;

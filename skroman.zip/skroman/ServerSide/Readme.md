# Do the Connection with mongdb Atlas.
Create a Cluster.

Create a database named skroman_dashboard.

Inside it, create a collection named company.

db.company.insertOne({
  name: "John Doe",
  email: "john@example.com",
  password: "123456789", //no hashed password
  roles: ["superadmin", "employee", "user", "client"]
});

.env - mongodb connection : MONGO_URI=mongodb://localhost:27017/skroman_dashboard

# run the code
- npm i
- npm start


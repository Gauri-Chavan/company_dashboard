# To run the application.
- Frontend 

- npm install
- npm run dev

- json-server --watch db.json --port 3001


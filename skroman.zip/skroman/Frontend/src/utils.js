export function saveAuthData(token, user) {
  const expiry = Date.now() + 60 * 60 * 1000; // 1 hour
  localStorage.setItem("token", token);
  localStorage.setItem("token_expiry", expiry);
  localStorage.setItem("user", JSON.stringify(user));
}

export function isTokenExpired() {
  const expiry = localStorage.getItem("token_expiry");
  return !expiry || Date.now() > Number(expiry);
}

export function logoutUser() {
  localStorage.removeItem("token");
  localStorage.removeItem("token_expiry");
  localStorage.removeItem("user");
  window.location.href = "/login"; // Redirect to login page
}

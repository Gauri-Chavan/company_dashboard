export const getUserData = (data) =>{
return (dispatch)=>{
dispatch({
    type : "getUserData",
    payload : data
})
}
};
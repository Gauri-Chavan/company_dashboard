import { useEffect, useState } from "react";
import { login } from "../../Api/authApi";
import { useNavigate } from "react-router-dom";
import "./Login.css";

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
 const tokenFromStorage = localStorage.getItem("token");
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = await login({ email, password });
      const { token, user, success } = data;
      if (success) {
        localStorage.setItem("token", token);
        localStorage.setItem("user", JSON.stringify(user));
        navigate("/dashboard");
      } else {
        alert("Login failed! Check your credentials.");
      }
    } catch (e) {
      console.error("Login error:", e.message);
      alert("Error logging in: " + e.message);
    }
  };
useEffect(() => {
  if (tokenFromStorage) { 
    navigate("/dashboard");
  }
}, [tokenFromStorage, navigate]);


  return (
    <div className="login-container">
      <form className="login-card" onSubmit={handleSubmit}>
        <h2 className="login-title">Welcome Back</h2>
        <p className="login-subtitle">Please login to continue</p>

        {/* Email Input */}
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        {/* Password Input with Show/Hide */}
        <div className="form-group password-wrapper">
          <label>Password</label>
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <span
            className="toggle-password"
            onClick={() => setShowPassword((prev) => !prev)}
          >
            {showPassword ? "🙈" : "👁️"}
          </span>
        </div>

        {/* Submit Button */}
        <button type="submit" className="btn-login">
          Login
        </button>
      </form>
    </div>
  );
}

import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";

function ProtectedRoute({ children, allowedRoles }) {
  const location = useLocation();
  const userData = useSelector((state) => state.user);

  // Prefer Redux token; fall back to localStorage
  const tokenFromStore = userData?.token;
  const tokenFromStorage = localStorage.getItem("token");
  const token = tokenFromStore || tokenFromStorage;

  // Optional role check prep
  const userRoles = userData?.user?.roles || JSON.parse(localStorage.getItem("user") || "{}")?.roles || [];

  // Auth check
  if (!token) {
    return <Navigate to="/" replace state={{ from: location }} />;
  }

  // Optional allowedRoles enforcement
  if (allowedRoles && allowedRoles.length > 0) {
    const allowed = userRoles.some((r) => allowedRoles.includes(r));
    if (!allowed) {
      // Could route to "Not authorized" page instead
      return <Navigate to="/" replace state={{ from: location }} />;
    }
  }

  return children;
}

export default ProtectedRoute;

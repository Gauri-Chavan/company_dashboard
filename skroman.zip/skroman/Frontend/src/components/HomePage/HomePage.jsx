import React, { useEffect, useState } from "react";
import LayoutAdmin from "../LayoutAdmin/LayoutAdmin";
import { Table, Spin } from "antd";
import axios from "axios";

function HomePage() {
  const [activeRole, setActiveRole] = useState("superadmin");
  const [activeTab, setActiveTab] = useState("");
  const [allData, setAllData] = useState({ employees: [], users: [], clients: [] });
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const pageSize = 5; 

  
  useEffect(() => {
    setLoading(true);
    axios
      .get("http://localhost:3001/superadmin")
      .then((res) => {
        setAllData(res.data); // Store all data (employees, users, clients)
      })
      .catch((err) => console.error("API error:", err))
      .finally(() => setLoading(false));
  }, []);

  // Update table data whenever activeRole or activeTab changes
  useEffect(() => {
    if (activeRole === "superadmin") {
      if (activeTab === "Total Employees") setData(allData.employees);
      else if (activeTab === "Total Users") setData(allData.users);
      else if (activeTab === "Total Clients") setData(allData.clients);
    } else if (activeRole === "employee") {
      setData(allData.employees);
    } else if (activeRole === "user") {
      setData(allData.users);
    } else if (activeRole === "client") {
      setData(allData.clients);
    }
    setPage(1);
  }, [activeRole, activeTab, allData]);

  // Slice data for pagination
  const paginatedData = data.slice((page - 1) * pageSize, page * pageSize);

  // Generate dynamic columns
  const columns = data.length
    ? Object.keys(data[0]).map((key) => ({
        title: key.toUpperCase(),
        dataIndex: key,
        key,
      }))
    : [];

  return (
    <LayoutAdmin
      activeRole={activeRole}
      setActiveRole={setActiveRole}
      activeTab={activeTab}
      setActiveTab={setActiveTab}
    >
      <Spin spinning={loading}>
        <Table
          dataSource={paginatedData}
          columns={columns}
          rowKey="id"
          pagination={{
            current: page,
            pageSize,
            total: data.length,
            onChange: (p) => setPage(p),
          }}
        />
      </Spin>
    </LayoutAdmin>
  );
}

export default HomePage;

import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Tooltip, Avatar } from "antd";
import "./LayoutAdmin.css";
import { store } from "../../store/store";
import { getUserData } from "../../Action/actions";

function LayoutAdmin({ children, activeRole, setActiveRole, activeTab, setActiveTab }) {
  const navigate = useNavigate();
  const userData = useSelector((state) => state.user);
 const dispatch = useDispatch();
  // Retrieve data from Redux or Local Storage
  const localStorageData = JSON.parse(localStorage.getItem("response") || "{}");
  const roles = userData?.user?.roles || localStorageData?.user?.roles || [];

  // Get user name
  const userName = userData?.user?.name || localStorageData?.user?.name || "User";

  const handleLogout = () => {
    localStorage.clear();
    store.dispatch(getUserData(null))
    navigate("/");
  };

  // Sidebar menu based on role
  const getSidebarMenu = () => {
    switch (activeRole) {
      case "superadmin":
        return ["Total Employees", "Total Users", "Total Clients"];
      case "employee":
        return ["Total Employees"];
      case "user":
        return ["Total Users"];
      case "client":
        return ["Total Clients"];
      default:
        return ["Dashboard"];
    }
  };

  const sidebarMenuItems = getSidebarMenu();

  // Ensure activeTab matches the current sidebar menu
  useEffect(() => {
    if (sidebarMenuItems.length > 0) {
      if (!activeTab || !sidebarMenuItems.includes(activeTab)) {
        setActiveTab(sidebarMenuItems[0]);
      }
    }
  }, [activeRole, sidebarMenuItems, activeTab, setActiveTab]);

  return (
    <div className="layout-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-logo avatar-section">
          <Tooltip title={userName}>
            <Avatar
              style={{
                backgroundColor: "#87d068",
                fontSize: "18px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
              }}
              size={40}
            >
              {userName.charAt(0).toUpperCase()}
            </Avatar>
          </Tooltip>
        </div>
        <ul className="sidebar-menu">
          {sidebarMenuItems.map((item, index) => (
            <li
              key={index}
              className={`sidebar-item ${activeTab === item ? "active" : ""}`}
              onClick={() => setActiveTab(item)}
            >
              {item}
            </li>
          ))}
        </ul>
      </aside>

      {/* Main Content Area */}
      <div className="main-content">
        <header className="header">
          <div>
            <h1 className="header-title">Dashboard</h1>
          </div>

          <div className="header-right">
            {/* Role Tabs */}
            <div className="role-tabs">
              {roles.map((role) => (
                <button
                  key={role}
                  className={`role-tab ${activeRole === role ? "active" : ""}`}
                  onClick={() => setActiveRole(role)}
                >
                  {role}
                </button>
              ))}
            </div>

            {/* Logout */}
            <button className="logout-btn" onClick={handleLogout}>
              Logout
            </button>
          </div>
        </header>

        <main className="content">{children}</main>
        <footer className="footer">Skroman ©2025-2026</footer>
      </div>
    </div>
  );
}

export default LayoutAdmin;

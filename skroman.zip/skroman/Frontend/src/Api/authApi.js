
import axios from "axios";
import { store } from "../store/store";
import { getUserData } from "../Action/actions";



const authApi = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  headers: { "Content-Type": "application/json" }
});

export async function login({ email, password }) {
  try {
    const res = await authApi.post("/login", { email, password });
    store.dispatch(getUserData(res.data))
localStorage.setItem("response", JSON.stringify(res.data)); 
    console.log("res",res.data)
    return res.data;
  } catch (err) {
    const message =
      err?.response?.data?.message ||
      err?.message ||
      "Login failed.";
    throw new Error(message);
  }
}


export default authApi;

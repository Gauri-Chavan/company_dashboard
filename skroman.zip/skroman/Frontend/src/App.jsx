import './App.css';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import LoginForm from './components/Login/Login';
import HomePage from './components/HomePage/HomePage.jsx';
import ProtectedRoute from './components/ProtectedRoute/ProtectedRoute.jsx';

// import { useEffect } from "react";
// import { isTokenExpired, logoutUser } from "./utils.js";

function App() {
  // Auto-logout timer (optional — see section 4 below)
  // useEffect(() => {
  //   if (isTokenExpired()) {
  //     logoutUser();
  //   } else {
  //     const remaining = Number(localStorage.getItem("token_expiry")) - Date.now();
  //     const id = setTimeout(() => logoutUser(), remaining);
  //     return () => clearTimeout(id);
  //   }
  // }, []);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginForm />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute allowedRoles={['superadmin','employee','user','client']}>
              <HomePage />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
